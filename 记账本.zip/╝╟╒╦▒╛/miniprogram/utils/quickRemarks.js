/**
 * 常用备注快捷输入
 */

// 支出常用备注
const expenseQuickRemarks = [
  '早餐',
  '午餐',
  '晚餐',
  '零食',
  '打车',
  '地铁',
  '公交',
  '日常用品',
  '衣服',
  '电影',
  '水果',
  '超市',
  '外卖'
];

// 收入常用备注
const incomeQuickRemarks = [
  '工资',
  '奖金',
  '报销',
  '兼职',
  '理财收益',
  '红包',
  '退款'
];

module.exports = {
  expenseQuickRemarks,
  incomeQuickRemarks
}; 