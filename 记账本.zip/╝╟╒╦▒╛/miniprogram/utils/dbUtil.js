/**
 * 数据库操作工具类
 */
const db = wx.cloud.database()
const _ = db.command

/**
 * 获取收入分类列表
 */
function getIncomeCategories() {
  return db.collection('categories')
    .where({
      type: 'income'
    })
    .orderBy('orderId', 'asc')
    .get()
}

/**
 * 获取支出分类列表
 */
function getExpenseCategories() {
  return db.collection('categories')
    .where({
      type: 'expense'
    })
    .orderBy('orderId', 'asc')
    .get()
}

/**
 * 添加账目记录
 * @param {Object} account 账目数据
 */
function addAccount(account) {
  return db.collection('accounts').add({
    data: {
      ...account,
      createTime: db.serverDate()
    }
  })
}

/**
 * 获取账目列表
 * @param {Object} options 查询选项
 */
function getAccounts(options = {}) {
  const { type, startDate, endDate, limit = 20, skip = 0 } = options
  
  let query = db.collection('accounts')
  
  // 构建查询条件
  let condition = {}
  
  if (type) {
    condition.type = type
  }
  
  if (startDate && endDate) {
    condition.date = _.gte(startDate).and(_.lte(endDate))
  } else if (startDate) {
    condition.date = _.gte(startDate)
  } else if (endDate) {
    condition.date = _.lte(endDate)
  }
  
  if (Object.keys(condition).length > 0) {
    query = query.where(condition)
  }
  
  // 按时间倒序排列
  return query.orderBy('date', 'desc')
    .skip(skip)
    .limit(limit)
    .get()
}

/**
 * 获取账目统计数据
 * @param {Object} options 查询选项
 */
function getAccountsStats(options = {}) {
  // 由于小程序云数据库不支持直接聚合计算
  // 这里返回筛选后的数据，由前端计算统计值
  return getAccounts(options)
}

/**
 * 删除账目记录
 * @param {String} id 账目ID
 */
function removeAccount(id) {
  return db.collection('accounts').doc(id).remove()
}

/**
 * 更新账目记录
 * @param {String} id 账目ID
 * @param {Object} data 更新数据
 */
function updateAccount(id, data) {
  return db.collection('accounts').doc(id).update({
    data
  })
}

module.exports = {
  getIncomeCategories,
  getExpenseCategories,
  addAccount,
  getAccounts,
  getAccountsStats,
  removeAccount,
  updateAccount
} 