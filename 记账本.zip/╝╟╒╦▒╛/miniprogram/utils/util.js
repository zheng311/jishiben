/**
 * 常用工具函数
 */

/**
 * 格式化日期为 YYYY-MM-DD 格式
 * @param {Date} date 日期对象
 * @returns {string} 格式化后的日期字符串
 */
const formatDate = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()

  return [year, month, day].map(formatNumber).join('-')
}

/**
 * 格式化数字，小于10前面补0
 * @param {number} n 数字
 * @returns {string} 格式化后的字符串
 */
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}

/**
 * 格式化金额，保留两位小数
 * @param {number|string} amount 金额
 * @returns {string} 格式化后的金额字符串
 */
const formatAmount = amount => {
  if (typeof amount === 'string') {
    amount = parseFloat(amount);
  }
  return amount.toFixed(2)
}

/**
 * 防抖函数
 * @param {Function} fn 要执行的函数
 * @param {number} delay 延迟时间（毫秒）
 */
function debounce(fn, delay = 500) {
  let timer = null
  
  return function(...args) {
    if (timer) {
      clearTimeout(timer)
    }
    
    timer = setTimeout(() => {
      fn.apply(this, args)
      timer = null
    }, delay)
  }
}

/**
 * 将日期对象格式化为人性化字符串
 * @param {Date} date 日期对象
 * @returns {string} 格式化后的日期字符串，如"今天"、"昨天"等
 */
const formatDateToFriendly = date => {
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)
  
  const dateDay = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  
  if (dateDay.getTime() === today.getTime()) {
    return '今天'
  } else if (dateDay.getTime() === yesterday.getTime()) {
    return '昨天'
  } else {
    return formatDate(date)
  }
}

/**
 * 获取最近30天的日期范围
 * @returns {Object} 包含开始日期和结束日期的对象
 */
const getLast30DaysRange = () => {
  const end = new Date()
  const start = new Date()
  start.setDate(start.getDate() - 29)
  
  return {
    startDate: new Date(start.getFullYear(), start.getMonth(), start.getDate()),
    endDate: new Date(end.getFullYear(), end.getMonth(), end.getDate(), 23, 59, 59)
  }
}

/**
 * 按日期分组账目数据
 * @param {Array} accounts 账目数据数组
 * @returns {Object} 按日期分组后的数据
 */
const groupAccountsByDate = accounts => {
  const grouped = {}
  
  accounts.forEach(account => {
    const dateStr = account.date
    
    if (!grouped[dateStr]) {
      grouped[dateStr] = []
    }
    
    grouped[dateStr].push(account)
  })
  
  return grouped
}

module.exports = {
  formatDate,
  formatNumber,
  formatAmount,
  debounce,
  formatDateToFriendly,
  getLast30DaysRange,
  groupAccountsByDate
} 