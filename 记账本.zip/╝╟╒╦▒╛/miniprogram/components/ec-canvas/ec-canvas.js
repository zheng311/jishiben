// components/ec-canvas/ec-canvas.js
import * as echarts from './echarts';

Component({
  properties: {
    canvasId: {
      type: String,
      value: 'ec-canvas'
    },

    ec: {
      type: Object
    }
  },

  data: {
    ec: null
  },

  ready: function () {
    if (!this.data.ec) {
      console.warn('组件需要绑定 ec 变量，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>');
      return;
    }

    if (!this.data.ec.onInit) {
      console.warn('组件需要绑定 ec.onInit 函数，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>');
      return;
    }
    
    this.init();
  },

  methods: {
    init: function () {
      const self = this;
      const ctx = wx.createCanvasContext(this.data.canvasId, this);

      const canvas = new echarts.WxCanvas(ctx, this.data.canvasId);
      echarts.setCanvasCreator(() => {
        return canvas;
      });

      const query = wx.createSelectorQuery().in(this);
      query.select('.ec-canvas').boundingClientRect(res => {
        if (res) {
          const canvasWidth = res.width;
          const canvasHeight = res.height;
          
          const dpr = wx.getSystemInfoSync().pixelRatio;
          canvas.width = canvasWidth * dpr;
          canvas.height = canvasHeight * dpr;
          
          const initResult = this.data.ec.onInit(canvas, canvasWidth, canvasHeight, dpr);

          // 注入事件处理方法
          if (initResult) {
            initResult.setOption = (option) => {
              if (option) {
                initResult.setOption(option);
              }
            };
          }
        } else {
          console.error('获取宽高失败，请确保已设置 ec-canvas 的 CSS 宽高');
        }
      }).exec();
    }
  }
}); 