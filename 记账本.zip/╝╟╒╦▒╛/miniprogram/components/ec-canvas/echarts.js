// 简化版ECharts库，用于微信小程序
class WxCanvas {
  constructor(ctx, canvasId) {
    this.ctx = ctx;
    this.canvasId = canvasId;
    this.chart = null;
    
    // 设置默认宽高
    this.width = 300;
    this.height = 200;
  }
  
  // 绘制方法
  draw() {
    this.ctx.draw(true);
  }
}

// 设置Canvas创建器
let canvasCreator = null;
function setCanvasCreator(creator) {
  canvasCreator = creator;
}

// 初始化图表
function init(canvas, width, height, dpr) {
  const chart = {
    canvas: canvas,
    width: width,
    height: height,
    dpr: dpr,
    option: null,
    
    // 设置图表配置项
    setOption: function(option) {
      this.option = option;
      this._render();
    },
    
    // 渲染图表
    _render: function() {
      const { ctx } = this.canvas;
      const { title, xAxis, yAxis, series } = this.option;
      
      // 清空画布
      ctx.clearRect(0, 0, this.width, this.height);
      
      // 绘制标题
      if (title && title.text) {
        ctx.fillStyle = '#333';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(title.text, this.width / 2, 30);
      }
      
      // 计算图表区域
      const padding = {
        top: 50,
        right: 20,
        bottom: 60,
        left: 60
      };
      
      const chartArea = {
        x: padding.left,
        y: padding.top,
        width: this.width - padding.left - padding.right,
        height: this.height - padding.top - padding.bottom
      };
      
      // 绘制Y轴
      ctx.beginPath();
      ctx.moveTo(chartArea.x, chartArea.y);
      ctx.lineTo(chartArea.x, chartArea.y + chartArea.height);
      ctx.strokeStyle = '#ccc';
      ctx.stroke();
      
      // 绘制X轴
      ctx.beginPath();
      ctx.moveTo(chartArea.x, chartArea.y + chartArea.height);
      ctx.lineTo(chartArea.x + chartArea.width, chartArea.y + chartArea.height);
      ctx.strokeStyle = '#ccc';
      ctx.stroke();
      
      // 绘制X轴标签
      if (xAxis && xAxis.data && xAxis.data.length > 0) {
        const step = chartArea.width / xAxis.data.length;
        ctx.fillStyle = '#666';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        
        xAxis.data.forEach((label, index) => {
          const x = chartArea.x + step * (index + 0.5);
          ctx.fillText(label, x, chartArea.y + chartArea.height + 20);
        });
      }
      
      // 绘制图表数据
      if (series && series.length > 0 && xAxis && xAxis.data) {
        const seriesData = series[0].data;
        const step = chartArea.width / seriesData.length;
        
        // 计算最大值以确定比例
        const maxValue = Math.max(...seriesData, 1);
        const ratio = chartArea.height / maxValue;
        
        if (series[0].type === 'bar') {
          // 绘制柱状图
          ctx.fillStyle = series[0].itemStyle ? series[0].itemStyle.color : '#07c160';
          
          seriesData.forEach((value, index) => {
            const barWidth = step * 0.6;
            const x = chartArea.x + step * index + (step - barWidth) / 2;
            const height = value * ratio;
            const y = chartArea.y + chartArea.height - height;
            
            ctx.fillRect(x, y, barWidth, height);
          });
        } else if (series[0].type === 'line') {
          // 绘制折线图
          ctx.beginPath();
          ctx.strokeStyle = series[0].itemStyle ? series[0].itemStyle.color : '#07c160';
          ctx.lineWidth = 2;
          
          seriesData.forEach((value, index) => {
            const x = chartArea.x + step * (index + 0.5);
            const y = chartArea.y + chartArea.height - value * ratio;
            
            if (index === 0) {
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
            }
          });
          
          ctx.stroke();
          
          // 绘制数据点
          ctx.fillStyle = series[0].itemStyle ? series[0].itemStyle.color : '#07c160';
          
          seriesData.forEach((value, index) => {
            const x = chartArea.x + step * (index + 0.5);
            const y = chartArea.y + chartArea.height - value * ratio;
            
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
          });
        }
      }
      
      // 绘制
      this.canvas.draw();
    }
  };
  
  return chart;
}

module.exports = {
  WxCanvas,
  setCanvasCreator,
  init
}; 