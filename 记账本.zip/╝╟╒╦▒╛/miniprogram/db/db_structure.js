/**
 * 记账本数据库结构设计
 */

// accounts 集合 - 账目记录
const accountsSchema = {
  "_id": "账目ID，自动生成",
  "type": "账目类型，'income'表示收入，'expense'表示支出",
  "amount": "金额，Number类型，单位为元",
  "categoryId": "分类ID，关联categories集合",
  "date": "记账日期，Date类型",
  "remark": "备注信息，String类型，可选",
  "userId": "用户ID，关联用户集合",
  "createTime": "创建时间，Date类型，自动生成"
}

// categories 集合 - 收支分类
const categoriesSchema = {
  "_id": "分类ID，自动生成",
  "name": "分类名称，如'餐饮'、'交通'等",
  "type": "分类类型，'income'表示收入分类，'expense'表示支出分类",
  "icon": "分类图标名称或路径",
  "orderId": "排序ID，Number类型，决定显示顺序"
}

// 预设的收入分类数据
const incomeCategories = [
  { name: "工资", type: "income", icon: "salary", orderId: 1 },
  { name: "奖金", type: "income", icon: "bonus", orderId: 2 },
  { name: "兼职", type: "income", icon: "parttime", orderId: 3 },
  { name: "理财", type: "income", icon: "investment", orderId: 4 },
  { name: "退款", type: "income", icon: "refund", orderId: 5 },
  { name: "红包", type: "income", icon: "redpacket", orderId: 6 },
  { name: "其他", type: "income", icon: "other", orderId: 7 }
]

// 预设的支出分类数据
const expenseCategories = [
  { name: "餐饮", type: "expense", icon: "food", orderId: 1 },
  { name: "购物", type: "expense", icon: "shopping", orderId: 2 },
  { name: "日用", type: "expense", icon: "daily", orderId: 3 },
  { name: "交通", type: "expense", icon: "transport", orderId: 4 },
  { name: "住房", type: "expense", icon: "house", orderId: 5 },
  { name: "娱乐", type: "expense", icon: "entertainment", orderId: 6 },
  { name: "医疗", type: "expense", icon: "medical", orderId: 7 },
  { name: "教育", type: "expense", icon: "education", orderId: 8 },
  { name: "通讯", type: "expense", icon: "communication", orderId: 9 },
  { name: "服饰", type: "expense", icon: "clothes", orderId: 10 },
  { name: "旅行", type: "expense", icon: "travel", orderId: 11 },
  { name: "其他", type: "expense", icon: "other", orderId: 12 }
]

module.exports = {
  accountsSchema,
  categoriesSchema,
  incomeCategories,
  expenseCategories
} 