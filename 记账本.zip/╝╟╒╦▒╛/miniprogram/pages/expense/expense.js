// pages/expense/expense.js
const { formatDate, debounce } = require('../../utils/util')
const { expenseQuickRemarks } = require('../../utils/quickRemarks')

Page({
  data: {
    type: 'expense',
    amount: '',
    currentDate: formatDate(new Date()),
    categories: [
      { name: "餐饮", type: "expense", icon: "food", id: "1" },
      { name: "购物", type: "expense", icon: "shopping", id: "2" },
      { name: "日用", type: "expense", icon: "daily", id: "3" },
      { name: "交通", type: "expense", icon: "transport", id: "4" },
      { name: "住房", type: "expense", icon: "house", id: "5" },
      { name: "娱乐", type: "expense", icon: "entertainment", id: "6" },
      { name: "医疗", type: "expense", icon: "medical", id: "7" },
      { name: "教育", type: "expense", icon: "education", id: "8" },
      { name: "通讯", type: "expense", icon: "communication", id: "9" },
      { name: "服饰", type: "expense", icon: "clothes", id: "10" },
      { name: "旅行", type: "expense", icon: "travel", id: "11" },
      { name: "其他", type: "expense", icon: "other", id: "12" }
    ],
    selectedCategory: null,
    remark: '',
    showCategoryPicker: false,
    showRemarkInput: false,
    activeTab: 'expense',
    quickRemarks: expenseQuickRemarks,
    isSubmitting: false,
    accounts: [] // 用于存储记账记录
  },

  onLoad: function (options) {
    // 设置默认选中的分类
    this.setData({
      selectedCategory: this.data.categories[0]
    })
    
    // 使用防抖函数包装提交方法
    this.debouncedSubmit = debounce(this.submitFormImpl, 500)
    
    // 从本地存储加载记账记录
    this.loadAccounts()
  },

  onShow: function () {
    // 每次显示页面时重新加载记录
    this.loadAccounts()
  },
  
  // 加载记账记录
  loadAccounts: function() {
    const accounts = wx.getStorageSync('accounts') || []
    // 只显示支出类型的记录
    const expenseAccounts = accounts.filter(item => item.type === 'expense')
    this.setData({
      accounts: expenseAccounts
    })
  },

  // 切换 Tab
  switchTab: function (e) {
    const tab = e.currentTarget.dataset.tab
    if (tab === 'expense') {
      // 当前已经是支出页面，不需要切换
      return
    }
    
    // 跳转到收入页面
    wx.switchTab({
      url: '/pages/income/income'
    })
  },

  // 金额输入处理
  onAmountInput: function (e) {
    const value = e.detail.value
    // 限制只能输入数字和小数点，且小数点后最多两位
    const reg = /^\d*(\.\d{0,2})?$/
    if (reg.test(value) || value === '') {
      this.setData({
        amount: value
      })
    } else {
      return this.data.amount
    }
  },

  // 日期选择处理
  onDateChange: function (e) {
    this.setData({
      currentDate: e.detail.value
    })
  },

  // 显示分类选择器
  showCategoryPicker: function () {
    this.setData({
      showCategoryPicker: true
    })
  },

  // 选择分类
  onCategorySelect: function (e) {
    const index = e.currentTarget.dataset.index
    this.setData({
      selectedCategory: this.data.categories[index],
      showCategoryPicker: false
    })
  },

  // 关闭分类选择器
  closeCategoryPicker: function () {
    this.setData({
      showCategoryPicker: false
    })
  },

  // 显示备注输入框
  showRemarkInput: function () {
    this.setData({
      showRemarkInput: true
    })
  },

  // 关闭备注输入框
  closeRemarkInput: function () {
    this.setData({
      showRemarkInput: false
    })
  },

  // 备注输入处理
  onRemarkInput: function (e) {
    this.setData({
      remark: e.detail.value
    })
  },

  // 选择快捷备注
  selectQuickRemark: function (e) {
    const remark = e.currentTarget.dataset.remark
    this.setData({
      remark: remark
    })
  },

  // 保存备注
  saveRemark: function () {
    this.setData({
      showRemarkInput: false
    })
  },

  // 表单提交（防抖包装）
  submitForm: function () {
    if (this.data.isSubmitting) {
      return
    }
    
    this.setData({
      isSubmitting: true
    })
    
    this.debouncedSubmit()
  },

  // 实际的表单提交逻辑
  submitFormImpl: function () {
    const { amount, currentDate, selectedCategory, remark, type } = this.data
    
    // 表单验证
    if (!amount || parseFloat(amount) <= 0) {
      wx.showToast({
        title: '请输入有效金额',
        icon: 'none'
      })
      this.setData({
        isSubmitting: false
      })
      return
    }
    
    if (!selectedCategory) {
      wx.showToast({
        title: '请选择分类',
        icon: 'none'
      })
      this.setData({
        isSubmitting: false
      })
      return
    }
    
    wx.showLoading({
      title: '保存中',
    })
    
    // 构建账目数据
    const accountData = {
      id: Date.now().toString(), // 使用时间戳作为唯一ID
      type,
      amount: parseFloat(amount),
      categoryId: selectedCategory.id,
      categoryName: selectedCategory.name,
      categoryIcon: selectedCategory.icon,
      date: currentDate,
      remark: remark.trim(),
      createTime: new Date().toISOString()
    }
    
    // 保存到本地存储
    try {
      const accounts = wx.getStorageSync('accounts') || []
      accounts.unshift(accountData) // 将新记录添加到数组开头
      wx.setStorageSync('accounts', accounts)
      
      wx.hideLoading()
      wx.showToast({
        title: '添加成功',
        icon: 'success'
      })
      
      // 重置表单
      this.setData({
        amount: '',
        remark: '',
        isSubmitting: false,
        accounts: accounts.filter(item => item.type === 'expense') // 更新列表
      })
    } catch (err) {
      console.error('添加账目失败', err)
      wx.hideLoading()
      wx.showToast({
        title: '添加失败',
        icon: 'none'
      })
      this.setData({
        isSubmitting: false
      })
    }
  },
  
  // 删除记录
  deleteAccount: function(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '确定要删除这条记录吗？',
      success: (res) => {
        if (res.confirm) {
          const accounts = wx.getStorageSync('accounts') || []
          const newAccounts = accounts.filter(item => item.id !== id)
          wx.setStorageSync('accounts', newAccounts)
          
          this.setData({
            accounts: newAccounts.filter(item => item.type === 'expense')
          })
          
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          })
        }
      }
    })
  }
})