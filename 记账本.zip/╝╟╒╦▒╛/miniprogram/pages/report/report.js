// pages/report/report.js
const { formatDate, formatAmount, getLast30DaysRange, groupAccountsByDate } = require('../../utils/util')
import * as echarts from '../../components/ec-canvas/echarts'

let chart = null

// 初始化图表
function initChart(canvas, width, height, dpr) {
  chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  })
  canvas.setChart(chart)
  
  // 初始设置空数据
  const option = {
    title: {
      text: '近30天消费趋势',
      left: 'center'
    },
    tooltip: {
      trigger: 'axis',
      formatter: '{b}: {c}元'
    },
    xAxis: {
      type: 'category',
      data: [],
      axisTick: {
        alignWithLabel: true
      }
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        formatter: '{value}元'
      }
    },
    series: [{
      name: '消费金额',
      type: 'bar',
      data: [],
      itemStyle: {
        color: '#07c160'
      }
    }]
  }
  
  chart.setOption(option)
  return chart
}

Page({
  data: {
    dateRange: {
      startDate: formatDate(getLast30DaysRange().startDate),
      endDate: formatDate(getLast30DaysRange().endDate)
    },
    isLoading: true,
    totalExpense: 0,
    totalIncome: 0,
    dailyAvgExpense: 0,
    chartType: 'bar', // 'bar' 或 'line'
    ec: {
      onInit: initChart
    },
    mockData: { // 模拟数据，用于初始展示
      dates: ['4-1', '4-2', '4-3', '4-4', '4-5', '4-6', '4-7', '4-8', '4-9', '4-10', 
              '4-11', '4-12', '4-13', '4-14', '4-15', '4-16', '4-17', '4-18', '4-19', '4-20', 
              '4-21', '4-22', '4-23', '4-24', '4-25', '4-26', '4-27', '4-28', '4-29', '4-30'],
      values: [120, 90, 150, 80, 70, 110, 130, 90, 60, 100, 
               85, 95, 75, 105, 120, 90, 60, 70, 80, 110, 
               140, 100, 80, 90, 110, 70, 60, 90, 100, 80]
    }
  },

  onLoad: function (options) {
    // 加载数据
    this.loadData()
  },

  onShow: function () {
    // 每次显示页面时重新加载数据
    this.loadData()
  },

  // 切换图表类型
  switchChartType: function () {
    const newType = this.data.chartType === 'bar' ? 'line' : 'bar'
    this.setData({
      chartType: newType
    })
    
    // 更新图表
    this.updateChart()
  },

  // 加载数据
  loadData: function () {
    const { startDate, endDate } = this.data.dateRange
    
    this.setData({
      isLoading: true
    })
    
    try {
      // 从本地存储获取账目数据
      const accounts = wx.getStorageSync('accounts') || []
      
      // 筛选日期范围内的数据
      const startTime = new Date(startDate).getTime()
      const endTime = new Date(endDate).getTime()
      
      const filteredAccounts = accounts.filter(account => {
        const accountTime = new Date(account.date).getTime()
        return accountTime >= startTime && accountTime <= endTime
      })
      
      // 处理数据
      this.processData(filteredAccounts)
    } catch (err) {
      console.error('获取统计数据失败', err)
      wx.showToast({
        title: '获取数据失败',
        icon: 'none'
      })
      
      // 使用 mock 数据
      this.processData(this.generateMockData())
    } finally {
      this.setData({
        isLoading: false
      })
    }
  },

  // 处理数据
  processData: function (accounts) {
    if (!accounts || accounts.length === 0) {
      // 如果没有数据，使用模拟数据
      accounts = this.generateMockData()
    }
    
    // 计算总收入和总支出
    let totalExpense = 0
    let totalIncome = 0
    
    accounts.forEach(account => {
      if (account.type === 'expense') {
        totalExpense += account.amount
      } else {
        totalIncome += account.amount
      }
    })
    
    // 按日期分组数据
    const groupedData = this.groupDataByDate(accounts)
    
    // 计算日均消费
    const days = Object.keys(groupedData).length || 30
    const dailyAvgExpense = totalExpense / days
    
    this.setData({
      totalExpense: formatAmount(totalExpense),
      totalIncome: formatAmount(totalIncome),
      dailyAvgExpense: formatAmount(dailyAvgExpense)
    })
    
    // 更新图表
    this.updateChartWithData(groupedData)
  },

  // 按日期分组数据
  groupDataByDate: function (accounts) {
    const { startDate, endDate } = this.data.dateRange
    const start = new Date(startDate)
    const end = new Date(endDate)
    const dateMap = {}
    
    // 初始化日期范围内的所有日期
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = formatDate(d)
      dateMap[dateStr] = {
        expense: 0,
        income: 0
      }
    }
    
    // 统计每天的收支
    accounts.forEach(account => {
      const dateStr = account.date
      
      if (dateMap[dateStr]) {
        if (account.type === 'expense') {
          dateMap[dateStr].expense += account.amount
        } else {
          dateMap[dateStr].income += account.amount
        }
      }
    })
    
    return dateMap
  },

  // 更新图表数据
  updateChartWithData: function (groupedData) {
    if (!chart) {
      console.error('图表未初始化')
      return
    }
    
    const dates = []
    const values = []
    
    // 按日期排序
    const sortedDates = Object.keys(groupedData).sort()
    
    sortedDates.forEach(date => {
      // 提取月-日部分
      const monthDay = date.substring(5)
      dates.push(monthDay)
      values.push(parseFloat(groupedData[date].expense.toFixed(2)))
    })
    
    this.chartData = {
      dates,
      values
    }
    
    this.updateChart()
  },

  // 更新图表
  updateChart: function () {
    if (!chart || !this.chartData) {
      // 如果图表或数据不存在，使用模拟数据
      if (chart) {
        const { dates, values } = this.data.mockData
        chart.setOption({
          xAxis: {
            data: dates
          },
          series: [{
            name: '消费金额',
            type: this.data.chartType,
            data: values
          }]
        })
      }
      return
    }
    
    const { dates, values } = this.chartData
    
    chart.setOption({
      xAxis: {
        data: dates
      },
      series: [{
        name: '消费金额',
        type: this.data.chartType,
        data: values
      }]
    })
  },

  // 生成模拟数据
  generateMockData: function () {
    const { startDate, endDate } = this.data.dateRange
    const start = new Date(startDate)
    const end = new Date(endDate)
    const mockAccounts = []
    
    // 为每一天生成随机数据
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = formatDate(d)
      
      // 随机消费金额 50-200
      const expenseAmount = Math.random() * 150 + 50
      
      mockAccounts.push({
        type: 'expense',
        amount: expenseAmount,
        date: dateStr
      })
      
      // 随机生成部分日期的收入
      if (Math.random() > 0.7) {
        const incomeAmount = Math.random() * 1000 + 500
        mockAccounts.push({
          type: 'income',
          amount: incomeAmount,
          date: dateStr
        })
      }
    }
    
    return mockAccounts
  }
}) 