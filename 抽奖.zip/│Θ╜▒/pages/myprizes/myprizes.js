// myprizes.js
Page({
  data: {},
  onLoad: function() {
    console.log('我的奖品页面加载成功')
  },
  
  goBack() {
    wx.navigateBack();
  }
}) 