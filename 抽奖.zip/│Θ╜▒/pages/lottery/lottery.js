// lottery.js
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    prizes: [
      { name: '一等奖' },
      { name: '二等奖' },
      { name: '三等奖' },
      { name: '四等奖' },
      { name: '五等奖' },
      { name: '六等奖' },
      { name: '七等奖' },
      { name: '八等奖' }
    ],
    runningIndex: -1,
    isRunning: false,
    resultModalVisible: false,
    editModalVisible: false,
    editPrizes: [],
    prizeResult: null,
    speed: 100, // 初始速度
    times: 0, // 转动次数统计
    maxTimes: 30, // 最大转动次数
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 初始化奖品数据
    this.formatPrizeData();
  },

  // 格式化奖品数据
  formatPrizeData: function() {
    // 创建9个格子的数组，中间是开始按钮
    let formattedPrizes = [];
    const originalPrizes = this.data.prizes;
    
    for (let i = 0; i < 9; i++) {
      if (i === 4) {
        // 中间格子是开始按钮
        formattedPrizes.push({ name: '开始', isButton: true });
      } else {
        // 调整索引，跳过中间位置
        let prizeIndex = i;
        if (i > 4) prizeIndex = i - 1;
        
        if (prizeIndex < originalPrizes.length) {
          formattedPrizes.push(originalPrizes[prizeIndex]);
        } else {
          formattedPrizes.push({ name: '谢谢参与' });
        }
      }
    }

    this.setData({
      formattedPrizes: formattedPrizes
    });
  },

  // 开始抽奖
  startLottery: function() {
    if (this.data.isRunning) return;
    
    // 随机选择结果
    const randomIndex = Math.floor(Math.random() * this.data.prizes.length);
    const selectedPrize = this.data.prizes[randomIndex];
    
    // 使用setData确保数据更新触发视图层的变化
    this.setData({
      isRunning: true,
      times: 0,
      runningIndex: 0,
      speed: 100,
      prizeResult: selectedPrize
    });
    
    // 开始转动动画
    this.runLottery();
  },

  // 运行抽奖动画
  runLottery: function() {
    if (!this.data.isRunning) return;
    
    // 计算当前高亮位置，跳过中间的按钮
    let nextIndex = this.data.runningIndex + 1;
    if (nextIndex === 4) nextIndex = 5; // 跳过中间的按钮
    if (nextIndex > 8) nextIndex = 0;
    
    this.setData({
      runningIndex: nextIndex,
      times: this.data.times + 1
    });

    // 根据转动次数逐渐减慢速度
    let nextSpeed = this.data.speed;
    if (this.data.times > this.data.maxTimes * 0.7) {
      nextSpeed += 5; // 逐渐减慢
    }

    if (this.data.times >= this.data.maxTimes) {
      // 根据结果确定最终停止位置
      const prizeIndex = this.data.prizes.findIndex(
        prize => prize.name === this.data.prizeResult.name
      );
      
      // 将原始奖品索引转换为格子索引（需要跳过中间按钮）
      let finalIndex = prizeIndex;
      if (prizeIndex >= 4) finalIndex = prizeIndex + 1;
      
      // 如果当前位置等于最终位置，则停止
      if (nextIndex === finalIndex) {
        this.stopLottery();
        return;
      }
    }

    setTimeout(() => {
      this.runLottery();
    }, nextSpeed);
  },

  // 停止抽奖
  stopLottery: function() {
    // 确保prizeResult在视图层可以访问
    const currentPrize = this.data.prizeResult;
    
    this.setData({
      isRunning: false,
      resultModalVisible: true,
      // 再次设置prizeResult，确保数据更新
      prizeResult: currentPrize
    });
    
    console.log('抽奖结果:', this.data.prizeResult);
    // 添加调试信息
    console.log('弹窗显示状态:', this.data.resultModalVisible);
  },

  // 关闭结果弹窗
  closeResultModal: function() {
    this.setData({
      resultModalVisible: false,
      runningIndex: -1
    });
  },

  // 打开编辑弹窗
  openEditModal: function() {
    // 复制奖品数据用于编辑
    this.setData({
      editPrizes: JSON.parse(JSON.stringify(this.data.prizes)),
      editModalVisible: true
    });
  },

  // 更新编辑中的奖品名称
  updatePrizeName: function(e) {
    const index = e.currentTarget.dataset.index;
    const name = e.detail.value;
    
    let editPrizes = this.data.editPrizes;
    editPrizes[index].name = name;
    
    this.setData({
      editPrizes: editPrizes
    });
  },

  // 保存编辑的奖品
  saveEditPrizes: function() {
    this.setData({
      prizes: this.data.editPrizes,
      editModalVisible: false
    });
    
    // 更新格式化后的奖品数据
    this.formatPrizeData();
  },

  // 关闭编辑弹窗
  closeEditModal: function() {
    this.setData({
      editModalVisible: false
    });
  },

  // 重置奖品
  resetPrizes: function() {
    const defaultPrizes = [
      { name: '一等奖' },
      { name: '二等奖' },
      { name: '三等奖' },
      { name: '四等奖' },
      { name: '五等奖' },
      { name: '六等奖' },
      { name: '七等奖' },
      { name: '八等奖' }
    ];
    
    this.setData({
      editPrizes: defaultPrizes
    });
  },

  // 返回上一页
  navigateBack: function() {
    wx.navigateBack();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '幸运大转盘',
      path: '/pages/lottery/lottery'
    };
  }
}) 