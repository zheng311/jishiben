// index.js
Page({
  data: {},
  onLoad: function() {
    console.log('页面加载成功')
  },
  
  goToLottery() {
    wx.navigateTo({
      url: '../lottery/lottery',
      fail: (err) => {
        console.error('导航失败:', err);
        wx.showToast({
          title: '页面跳转失败',
          icon: 'none'
        });
      }
    });
  }
}) 