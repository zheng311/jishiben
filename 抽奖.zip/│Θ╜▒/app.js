// app.js
App({
  globalData: {},
  onLaunch() {
    console.log('小程序启动')
  }
}) 