Component({
  properties: {
    // 是否显示modal
    show: {
      type: Boolean,
      value: false
    },
    // 标题
    title: {
      type: String,
      value: ''
    },
    // 内容
    content: {
      type: String,
      value: ''
    },
    // 确认按钮文本
    confirmText: {
      type: String,
      value: '确定'
    },
    // 取消按钮文本
    cancelText: {
      type: String,
      value: '取消'
    },
    // 是否显示取消按钮
    showCancel: {
      type: Boolean,
      value: true
    },
    // 是否显示关闭图标
    showClose: {
      type: Boolean,
      value: true
    },
    // 自定义样式
    customStyle: {
      type: String,
      value: ''
    },
    // 点击蒙层是否关闭
    maskClosable: {
      type: Boolean,
      value: true
    }
  },

  data: {
    // 动画数据
    animationData: {}
  },

  lifetimes: {
    attached() {
      // 创建动画实例
      this.animation = wx.createAnimation({
        duration: 200,
        timingFunction: 'ease',
      })
    }
  },

  observers: {
    'show': function(value) {
      if (value) {
        this.showModal()
      } else {
        this.hideModal()
      }
    }
  },

  methods: {
    // 显示模态框
    showModal() {
      this.animation.opacity(1).scale(1).step()
      this.setData({
        animationData: this.animation.export()
      })
    },

    // 隐藏模态框
    hideModal() {
      this.animation.opacity(0).scale(0.8).step()
      this.setData({
        animationData: this.animation.export()
      })
    },

    // 点击蒙层
    onMaskClick() {
      if (this.data.maskClosable) {
        this.triggerEvent('cancel')
      }
    },

    // 点击关闭按钮
    onCloseClick() {
      this.triggerEvent('cancel')
    },

    // 点击确认按钮
    onConfirm() {
      this.triggerEvent('confirm')
    },

    // 点击取消按钮
    onCancel() {
      this.triggerEvent('cancel')
    },

    // 阻止冒泡
    preventBubble() {
      return false
    }
  }
}) 