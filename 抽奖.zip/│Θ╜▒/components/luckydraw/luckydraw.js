Component({
  properties: {
    // 奖品列表
    prizes: {
      type: Array,
      value: []
    },
    // 中奖索引，从0开始
    prizeIndex: {
      type: Number,
      value: -1
    },
    // 是否可以抽奖
    canDraw: {
      type: Boolean,
      value: true
    },
    // 转动圈数
    rounds: {
      type: Number,
      value: 5
    }
  },

  data: {
    // 当前选中索引
    currentIndex: 0,
    // 转动状态
    isDrawing: false,
    // 动画计时器
    timer: null,
    // 转速
    speed: 200,
    // 最慢转速
    minSpeed: 200,
    // 最快转速
    maxSpeed: 30,
    // 加速阶段次数
    speedUpTimes: 5,
    // 匀速阶段次数
    steadyTimes: 5,
    // 减速阶段次数
    slowDownTimes: 10,
    // 当前阶段
    currentStage: '',
    // 当前阶段计数
    stageCount: 0,
    // 总共转动次数
    totalCount: 0,
    // 九宫格排列顺序
    // 0 1 2
    // 7   3
    // 6 5 4
    indexMap: [0, 1, 2, 3, 4, 5, 6, 7]
  },

  lifetimes: {
    attached: function() {
      this.initCanvas()
    },
    
    detached: function() {
      if (this.data.timer) {
        clearTimeout(this.data.timer)
      }
    }
  },

  methods: {
    // 初始化Canvas
    initCanvas() {
      const query = this.createSelectorQuery()
      query.select('#luckydraw-canvas')
        .fields({ node: true, size: true })
        .exec((res) => {
          if (!res[0] || !res[0].node) return
          
          const canvas = res[0].node
          const ctx = canvas.getContext('2d')
          
          // 设置canvas尺寸
          this.setCanvasSize(canvas)
          
          // 保存canvas和ctx到this
          this.canvas = canvas
          this.ctx = ctx
          
          // 初始绘制
          this.drawLuckyGrid()
        })
    },
    
    // 设置canvas尺寸
    setCanvasSize(canvas) {
      const dpr = wx.getSystemInfoSync().pixelRatio
      const width = 300
      const height = 300
      
      canvas.width = width * dpr
      canvas.height = height * dpr
      
      this.canvasWidth = width
      this.canvasHeight = height
      this.dpr = dpr
    },
    
    // 绘制九宫格
    drawLuckyGrid() {
      if (!this.ctx) return
      
      const ctx = this.ctx
      const width = this.canvasWidth
      const height = this.canvasHeight
      const dpr = this.dpr
      
      // 清空画布
      ctx.clearRect(0, 0, width * dpr, height * dpr)
      
      // 设置比例
      ctx.scale(dpr, dpr)
      
      // 背景
      ctx.fillStyle = '#FFA940'
      ctx.fillRect(0, 0, width, height)
      
      // 中心区域
      ctx.fillStyle = '#fff'
      ctx.fillRect(width/3, height/3, width/3, height/3)
      
      // 绘制格子
      const cellWidth = width / 3
      const cellHeight = height / 3
      
      // 遍历格子
      for (let i = 0; i < 8; i++) {
        let x, y
        // 根据索引计算位置
        if (i < 3) { // 上边一行
          x = i * cellWidth
          y = 0
        } else if (i === 3) { // 右边
          x = 2 * cellWidth
          y = cellHeight
        } else if (i < 7) { // 下边一行 (倒序)
          x = (6 - i) * cellWidth
          y = 2 * cellHeight
        } else { // 左边
          x = 0
          y = cellHeight
        }
        
        const isActive = this.data.currentIndex === i && this.data.isDrawing
        
        // 绘制格子背景
        ctx.fillStyle = isActive ? '#FF4D4F' : '#fff'
        ctx.fillRect(x + 5, y + 5, cellWidth - 10, cellHeight - 10)
        
        // 绘制奖品名称
        if (this.data.prizes.length > 0) {
          const prizeIndex = this.data.indexMap[i]
          if (this.data.prizes[prizeIndex]) {
            ctx.fillStyle = isActive ? '#fff' : '#333'
            ctx.font = '14px Arial'
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.fillText(
              this.data.prizes[prizeIndex].name || '',
              x + cellWidth / 2,
              y + cellHeight / 2
            )
          }
        }
      }
      
      // 中心按钮
      ctx.fillStyle = this.data.canDraw && !this.data.isDrawing ? '#FF4D4F' : '#ccc'
      ctx.font = '18px Arial'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(
        this.data.isDrawing ? '抽奖中...' : '开始',
        width / 2,
        height / 2
      )
    },
    
    // 开始抽奖
    startDraw() {
      if (!this.data.canDraw || this.data.isDrawing) return
      
      this.triggerEvent('start')
      
      this.setData({
        isDrawing: true,
        currentIndex: 0,
        speed: this.data.minSpeed,
        currentStage: 'speedUp',
        stageCount: 0,
        totalCount: 0
      })
      
      this.runDrawAnimation()
    },
    
    // 设置抽奖结果并展示
    setResult(prizeIndex) {
      // 计算转动次数
      const totalRounds = this.data.rounds * 8 // 总转动圈数 * 每圈8格
      const targetIndex = this.getTargetIndex(prizeIndex)
      
      // 设置目标
      this.targetTotalCount = totalRounds + targetIndex
    },
    
    // 获取目标索引
    getTargetIndex(prizeIndex) {
      // 查找奖品在indexMap中的位置
      return this.data.indexMap.findIndex(index => index === prizeIndex)
    },
    
    // 运行抽奖动画
    runDrawAnimation() {
      if (!this.data.isDrawing) return
      
      // 清除上次定时器
      if (this.data.timer) {
        clearTimeout(this.data.timer)
      }
      
      // 更新当前索引
      let nextIndex = (this.data.currentIndex + 1) % 8
      
      this.setData({
        currentIndex: nextIndex,
        totalCount: this.data.totalCount + 1
      })
      
      // 绘制九宫格
      this.drawLuckyGrid()
      
      // 速度控制
      this.controlSpeed()
      
      // 检查是否结束
      if (this.checkShouldStop()) {
        this.stopDraw()
        return
      }
      
      // 继续动画
      this.setData({
        timer: setTimeout(() => {
          this.runDrawAnimation()
        }, this.data.speed)
      })
    },
    
    // 控制转速
    controlSpeed() {
      if (this.data.currentStage === 'speedUp') {
        // 加速阶段
        this.setData({
          stageCount: this.data.stageCount + 1
        })
        
        if (this.data.stageCount >= this.data.speedUpTimes) {
          // 进入匀速阶段
          this.setData({
            currentStage: 'steady',
            stageCount: 0,
            speed: this.data.maxSpeed
          })
        } else {
          // 加速
          const speedDiff = this.data.minSpeed - this.data.maxSpeed
          const speedStep = speedDiff / this.data.speedUpTimes
          this.setData({
            speed: this.data.minSpeed - speedStep * this.data.stageCount
          })
        }
      } else if (this.data.currentStage === 'steady') {
        // 匀速阶段
        this.setData({
          stageCount: this.data.stageCount + 1
        })
        
        if (this.data.stageCount >= this.data.steadyTimes && this.targetTotalCount) {
          // 进入减速阶段
          this.setData({
            currentStage: 'slowDown',
            stageCount: 0
          })
        }
      } else if (this.data.currentStage === 'slowDown') {
        // 减速阶段
        this.setData({
          stageCount: this.data.stageCount + 1
        })
        
        // 计算减速
        const speedDiff = this.data.minSpeed - this.data.maxSpeed
        const speedStep = speedDiff / this.data.slowDownTimes
        this.setData({
          speed: this.data.maxSpeed + speedStep * this.data.stageCount
        })
      }
    },
    
    // 检查是否应该停止
    checkShouldStop() {
      if (!this.targetTotalCount) return false
      
      // 在减速阶段且转动次数达到目标次数时停止
      return this.data.currentStage === 'slowDown' && 
             this.data.totalCount >= this.targetTotalCount
    },
    
    // 停止抽奖
    stopDraw() {
      this.setData({
        isDrawing: false
      })
      
      this.drawLuckyGrid()
      
      // 触发结束事件
      this.triggerEvent('end', {
        prizeIndex: this.data.prizeIndex
      })
    },
    
    // 重置抽奖
    reset() {
      if (this.data.timer) {
        clearTimeout(this.data.timer)
      }
      
      this.setData({
        isDrawing: false,
        currentIndex: 0,
        timer: null
      })
      
      this.drawLuckyGrid()
    },
    
    // 点击canvas
    onCanvasTap() {
      if (!this.data.isDrawing) {
        this.startDraw()
      }
    }
  }
}) 