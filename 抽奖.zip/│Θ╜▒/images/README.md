# 图片资源目录

此目录用于存放小程序中使用的图片资源。需要添加以下图片：

## Tab栏图标
- tab_home.png - 首页未选中图标
- tab_home_selected.png - 首页选中图标
- tab_my.png - 我的奖品未选中图标
- tab_my_selected.png - 我的奖品选中图标

## 轮播图
- banner1.png - 活动轮播图1
- banner2.png - 活动轮播图2
- banner3.png - 活动轮播图3

## 奖品图片
- prize_1.png - 一等奖图片
- prize_2.png - 二等奖图片
- prize_none.png - 谢谢参与图片

## 按钮图标
- draw_btn.png - 抽奖按钮图片
- btn_bg.png - 按钮背景图

## 其他图标
- arrow_right.png - 右箭头图标
- arrow_down.png - 下箭头图标
- empty.png - 空状态图标
- success.png - 成功图标

注意：请确保所有图片的分辨率足够高，且符合小程序对图片资源的要求。 