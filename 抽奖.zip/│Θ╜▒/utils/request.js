// request.js - 请求封装
const baseURL = 'https://api.example.com'; // 这里替换为实际的API地址

// 请求拦截
const request = (url, method = 'GET', data = {}) => {
  return new Promise((resolve, reject) => {
    // 检查是否是抽奖接口，如果是则使用本地mock数据
    if (url.includes('/lottery/draw')) {
      // 模拟抽奖接口
      setTimeout(() => {
        const prizeResult = mockLotteryDraw();
        resolve(prizeResult);
      }, 1000);
      return;
    }
    
    // 正常请求
    wx.request({
      url: baseURL + url,
      method,
      data,
      header: {
        'content-type': 'application/json'
      },
      success: (res) => {
        if (res.statusCode === 200) {
          resolve(res.data);
        } else {
          reject(res);
        }
      },
      fail: (err) => {
        reject(err);
      }
    });
  });
};

// 模拟抽奖结果
const mockLotteryDraw = () => {
  // 获取全局奖品数据
  const app = getApp();
  const prizes = app.globalData.prizes;
  
  // 生成随机数决定中奖结果
  const random = Math.random();
  let cumulativeProbability = 0;
  let result = null;
  
  // 根据概率选择奖品
  for (const prize of prizes) {
    cumulativeProbability += prize.probability;
    if (random < cumulativeProbability) {
      result = prize;
      break;
    }
  }
  
  // 如果获得了奖品（非谢谢参与），添加到我的奖品列表
  if (result && result.name !== '谢谢参与') {
    const newPrize = {
      id: Date.now(), // 使用时间戳作为唯一ID
      name: result.name,
      image: result.image,
      status: 0, // 0: 未使用, 1: 已过期
      expireTime: getExpireDate() // 设置过期时间为30天后
    };
    
    app.globalData.myPrizes.unshift(newPrize);
  }
  
  return {
    code: 0,
    message: '抽奖成功',
    data: result
  };
};

// 获取30天后的日期字符串
const getExpireDate = () => {
  const date = new Date();
  date.setDate(date.getDate() + 30);
  return date.toISOString().split('T')[0];
};

// 导出请求方法
module.exports = {
  request,
  get: (url, data) => request(url, 'GET', data),
  post: (url, data) => request(url, 'POST', data),
  put: (url, data) => request(url, 'PUT', data),
  delete: (url, data) => request(url, 'DELETE', data)
}; 